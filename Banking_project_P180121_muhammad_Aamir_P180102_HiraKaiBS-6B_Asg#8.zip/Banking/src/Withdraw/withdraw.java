package Withdraw;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import sample.Notifications;

import java.io.IOException;
import java.sql.*;

import static sample.Main.getConnection_object;

public class withdraw {

    public TextField enter_amount;
    private  static String cnic;
    private static String pin;
    private static int previous_balance;
    public Button withdraw_button;
    public AnchorPane withdraw_anchor_pane;

    @FXML
    private Button enter_button;

    @FXML
    private TextField enter_pin;
    @FXML
    private TextField enter_cnic;


    @FXML
    void button_clicked(ActionEvent event) throws SQLException, IOException {
        if(event.getSource() == enter_button)
        {
            System.out.println("button is Withdraw is clicked ++++++++++++++++++++++++++++");
            Connection con  = getConnection_object();
            String query = "select avail_balance from customer_account_view where cnic = ? and pin = ?" ;
            System.out.println("Button is clicked ");
            try {
                PreparedStatement stmt = con.prepareStatement(query);
                //Retrieving the data
                stmt.setString(1, enter_cnic.getText());
                stmt.setString(2, enter_pin.getText());
                cnic = enter_cnic.getText();
                pin = enter_pin.getText();
                ResultSet rs = stmt.executeQuery();


                System.out.println(rs);
                rs.next();
                previous_balance = rs.getInt("avail_balance");
                System.out.println(previous_balance);

            } catch (SQLException throwables) {
                Notifications.show_Error_Notification("Account is not present", "Invalid Account");

                throwables.printStackTrace();

            }
            System.out.println("setting up next pane in withdraw package");
            AnchorPane my_pane = FXMLLoader.load(getClass().getResource("enter_amount_to_withdraw.fxml"));

            withdraw_anchor_pane.getChildren().setAll(my_pane);

        }
        else if(event.getSource() == withdraw_button)
        {
            Connection con  = getConnection_object();
            if (!enter_amount.getText().matches("[0-9]+") )
            {
                Notifications.show_Error_Notification("Please enter valid Amount  " , "Invalid  Amount");
                return;
            }
            if ( Integer.parseInt(enter_amount.getText()) > previous_balance)
            {
                Notifications.show_Error_Notification("Your total amount is  " + previous_balance, "Insufficient Amount");
                return;
            }
            System.out.println("preivous balance is is is " +  String.valueOf(previous_balance));
            System.out.println("cnic is " + cnic);
            System.out.println("pin is " + pin);
            int present_amount = Integer.parseInt(enter_amount.getText());

            previous_balance -=  present_amount;

            String query = "update customer_account_view set avail_balance = ? where cnic = ? and pin = ?" ;
            String qury2 = "insert into withdraw_history(id,withdraw_amount,withdraw_date) value(?,?,curdate()) ";
            String query3 = "select id from CUSTOMERS where cnic = ? and pin = ?";

            PreparedStatement stmt = con.prepareStatement(query3);
            stmt.setString(1, cnic);
            stmt.setString(2, pin);

         ResultSet   rs = stmt.executeQuery();
         rs.next();
         int id = rs.getInt("id");
            System.out.println(" selected or let say elected id is " + id);


             stmt = con.prepareStatement(query);
            stmt.setString(1, String.valueOf(previous_balance));
            stmt.setString(2, cnic);
            stmt.setString(3, pin);
            stmt.executeUpdate();
            con.commit();
            stmt = con.prepareStatement(qury2);
            stmt.setInt(1, id);
            stmt.setInt(2, present_amount);
            stmt.executeUpdate();
            con.commit();

            System.out.println(previous_balance);
            System.out.println("preivous balance is is is " +  String.valueOf(previous_balance));
            Notifications.show_Success_Notification("Your new Account balance is  "+ previous_balance + " !! Take your Amount", "Withdraw Success");
//////////////////// below two lines are   to close the current window      ////////////
            Stage stage = (Stage) withdraw_button.getScene().getWindow();
            stage.close();

        }



    }


}
