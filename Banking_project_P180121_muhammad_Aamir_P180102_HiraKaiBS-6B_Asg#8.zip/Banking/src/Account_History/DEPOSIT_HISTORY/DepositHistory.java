package Account_History.DEPOSIT_HISTORY;

// this is the controller class
import Account_History.validate_user;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import sample.Main;

import java.sql.ResultSet;
import java.sql.*;


public class DepositHistory {
    @FXML
    private TableColumn<String, Deposit_history_info> deposit_date;

    @FXML
    private TableColumn<Integer, Deposit_history_info> deposit_amount;

    @FXML
    private Label label;

    @FXML
    private Pane panel;

    @FXML
    private TableView<Deposit_history_info> table;
   
    private ResultSet rs;
    private PreparedStatement stmt;
    private Connection con;
    private String date;
    private int amount;

    public ObservableList<Deposit_history_info> getDepositHistory()
    {
        con = null;
        String query = "select DATE_FORMAT(deposit_date,'%D %M %Y')AS deposit_date,deposit_amount from deposit_history natural join CUSTOMERS where id = ? order by deposit_date desc;";
        rs = null;
        ObservableList<Deposit_history_info> my_deposit_history_list = FXCollections.observableArrayList();

        try {

            con = Main.getConnection_object();

            stmt = con.prepareStatement(query);
            stmt.setInt(1, validate_user.get_user_id());


            rs = stmt.executeQuery();

            while(rs.next())
            {
                System.out.println("HEHEHEEHHE");
                date = rs.getString("deposit_date");

                amount = rs.getInt("deposit_amount");

                my_deposit_history_list.add(new Deposit_history_info(date, amount));

//                Total_students_or_teachers += 1;
            }
//            label.setText("Total Students */are " + Total_students_or_teachers);

        }catch (Exception e){//do nothing
            System.out.println("Error in connection " + e);
        }
        System.out.println("Observable list is called correctly");
//        teacher.add(new remove_teacher_info(23, "Safiullah", "medical"));
        System.out.println(my_deposit_history_list);
        return my_deposit_history_list;
    }
    @FXML
    private void initialize() {
        // this method will call automatically when all fxml files are loaded
        execute_table();
    }
    public void execute_table()
    {


        deposit_date.setCellValueFactory(new PropertyValueFactory<>("deposit_date"));
        deposit_amount.setCellValueFactory(new PropertyValueFactory<>("deposit_amount"));
        ObservableList<Deposit_history_info> get_list  = getDepositHistory();
        System.out.println("returned back");
//        System.out.println(get_list.get(0).getDeposit());
        table.setItems(get_list);

    }
}

