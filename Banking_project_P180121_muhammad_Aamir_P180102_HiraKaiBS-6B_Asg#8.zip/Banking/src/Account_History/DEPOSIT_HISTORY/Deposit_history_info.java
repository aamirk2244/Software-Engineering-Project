package Account_History.DEPOSIT_HISTORY;

// this class is for Table making
public class Deposit_history_info {
    private String deposit_date;
    private int deposit_amount;

    public Deposit_history_info(String deposit_date, int deposit_amount) {
        this.deposit_date = deposit_date;
        this.deposit_amount = deposit_amount;
    }

    public String getDeposit_date() {
        return deposit_date;
    }

    public void setDeposit_date(String deposit_date) {
        this.deposit_date = deposit_date;
    }

    public int getDeposit_amount() {
        return deposit_amount;
    }

    public void setDeposit_amount(int deposit_amount) {
        this.deposit_amount = deposit_amount;
    }

}