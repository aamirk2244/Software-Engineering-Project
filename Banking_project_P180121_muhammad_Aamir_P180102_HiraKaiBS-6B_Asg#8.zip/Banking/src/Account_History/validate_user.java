
package Account_History;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import sample.Main;
import sample.Notifications;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static sample.Main.getConnection_object;


public class validate_user {

    private static int id;
    public AnchorPane my_anchor;
    public TextField enter_cnic;
    public TextField enter_pin;
    @FXML
    private Button submit;

    private ResultSet rs;

    public static int get_user_id(){return id; }
    @FXML
    void button_clicked(ActionEvent event) throws SQLException, IOException {
        Connection con =  Main.getConnection_object();
        String query = "select id from CUSTOMERS where  cnic = ? and pin = ? "; // checking if user present
        PreparedStatement stmt = con.prepareStatement(query);
        try {

            stmt.setString(1, enter_cnic.getText());
            stmt.setString(2, enter_pin.getText());

            rs = stmt.executeQuery();

            while(rs.next())
            {
                id = rs.getInt("id");

            }


//            Stage stage = (Stage) submit.getScene().getWindow();
//            stage.close();
            ///
            if(HistoryOption.was_deposit_button_clicked())
            {

                System.out.println("yes Deposit  button was clicked previously ");
                Parent my_pane = FXMLLoader.load(getClass().getResource("/Account_History/DEPOSIT_HISTORY/deposit_history.fxml"));

            my_anchor.getChildren().setAll(my_pane);

                // load deposit file
            }
            else if(HistoryOption.was_withdraw_button_clicked())
            {
                // load withdraw file
                System.out.println("yes withdraw button was clicked previously ");
                Parent my_pane = FXMLLoader.load(getClass().getResource("/Account_History/WITHDRAW_HISTORY/withdraw_history.fxml"));

                my_anchor.getChildren().setAll(my_pane);


            }


        } catch (SQLException throwables) {

            Notifications.show_Error_Notification("The account is not present", "Invalid Account");
            throwables.printStackTrace();

        }
        return;


    }

}
