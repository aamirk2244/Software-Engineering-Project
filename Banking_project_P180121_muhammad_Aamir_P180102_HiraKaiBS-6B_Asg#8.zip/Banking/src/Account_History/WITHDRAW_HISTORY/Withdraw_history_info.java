package Account_History.WITHDRAW_HISTORY;

// this class is for Table making
public class Withdraw_history_info {
    private String withdraw_date;
    private int withdraw_amount;

    public Withdraw_history_info(String withdraw_date, int withdraw_amount) {
        this.withdraw_date = withdraw_date;
        this.withdraw_amount = withdraw_amount;
    }

    public String getWithdraw_date() {
        return withdraw_date;
    }

    public void setWithdraw_date(String deposit_date) {
        this.withdraw_date = deposit_date;
    }

    public int getWithdraw_amount() {
        return withdraw_amount;
    }

    public void setWithdraw_amount(int withdraw_amount) {
        this.withdraw_amount = withdraw_amount;
    }

}