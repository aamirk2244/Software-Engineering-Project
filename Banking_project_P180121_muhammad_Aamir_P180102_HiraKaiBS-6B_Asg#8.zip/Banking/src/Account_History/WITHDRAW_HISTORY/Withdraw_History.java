package Account_History.WITHDRAW_HISTORY;

// this is the controller class
import Account_History.WITHDRAW_HISTORY.Withdraw_history_info;
import Account_History.validate_user;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import sample.Main;

import java.sql.ResultSet;
import java.sql.*;


public class Withdraw_History {
    @FXML
    private TableColumn<String, Withdraw_history_info> withdraw_date;

    @FXML
    private TableColumn<Integer, Withdraw_history_info> withdraw_amount;

    @FXML
    private Label label;

    @FXML
    private Pane panel;

    @FXML
    private TableView<Withdraw_history_info> table;

    private ResultSet rs;
    private PreparedStatement stmt;
    private Connection con;
    private String date;
    private int amount;

    public ObservableList<Withdraw_history_info> getWithdrawHistory()
    {
        con = null;
        String query = "select DATE_FORMAT(withdraw_date,'%D %M %Y')AS withdraw_date,withdraw_amount from withdraw_history natural join CUSTOMERS where id = ? order by withdraw_date desc;";
        rs = null;
        ObservableList<Withdraw_history_info> my_withdraw_history_list = FXCollections.observableArrayList();

        try {

            con = Main.getConnection_object();
            stmt = con.prepareStatement(query);
            stmt.setInt(1, validate_user.get_user_id());


            rs = stmt.executeQuery();

            while(rs.next())
            {
                System.out.println("HEHEHEEHHE");
                date = rs.getString("withdraw_date");

                amount = rs.getInt("withdraw_amount");

                my_withdraw_history_list.add(new Withdraw_history_info(date, amount));

//                Total_students_or_teachers += 1;
            }
//            label.setText("Total Students */are " + Total_students_or_teachers);

        }catch (Exception e){//do nothing
            System.out.println("Error in connection " + e);
        }
        System.out.println("Observable list is called correctly");;
        System.out.println(my_withdraw_history_list);
        return my_withdraw_history_list;
    }
    @FXML
    private void initialize() {
        // this method will call automatically when all fxml files are loaded
        execute_table();
    }
    public void execute_table()
    {


        withdraw_date.setCellValueFactory(new PropertyValueFactory<>("withdraw_date"));
        withdraw_amount.setCellValueFactory(new PropertyValueFactory<>("withdraw_amount"));
        ObservableList<Withdraw_history_info> get_list  = getWithdrawHistory();
        System.out.println("returned back");
//        System.out.println(get_list.get(0).getDeposit());
        table.setItems(get_list);

    }
}

