package Account_History;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import sample.Main;

import java.io.IOException;

public class HistoryOption {

    public BorderPane Border_pane;
    @FXML
    private Button withdraw_history;

    @FXML
    private Button deposit_history;
    private static  boolean is_deposit;

    private static boolean is_withdraw;

    public static  boolean was_withdraw_button_clicked(){return is_withdraw;}
    public static  boolean was_deposit_button_clicked(){return is_deposit;}


    @FXML
    void button_clicked(ActionEvent event) throws IOException {
        if(event.getSource() == deposit_history)
        {
            is_deposit = true;
            is_withdraw = false;
            System.out.println( "deposit_history button is clicked ");
//            Stage stage = (Stage) deposit_history.getScene().getWindow();
//            stage.close();
//            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/DEPOSIT_HISTORY/deposit_history.fxml"));
//
//            Main.set_stage("Deposit History",  fxmlLoader);
            Parent my_grid = FXMLLoader.load(getClass().getResource("/Account_History/validateUser.fxml"));
            Border_pane.getChildren().setAll(my_grid);

            System.out.println("controll camme to me +++++++++++++++++++++++++++++++++++++++++++++++=");

        }
        else if(event.getSource() == withdraw_history)
        {
            is_deposit = false;
            is_withdraw = true;
//            Parent my_grid = FXMLLoader.load(getClass().getResource("/Account_History/WITHDRAW_HISTORY/withdraw_history.fxml"));
//            Border_pane.getChildren().setAll(my_grid);

            Parent my_grid = FXMLLoader.load(getClass().getResource("/Account_History/validateUser.fxml"));
            Border_pane.getChildren().setAll(my_grid);



        }

    }
}
