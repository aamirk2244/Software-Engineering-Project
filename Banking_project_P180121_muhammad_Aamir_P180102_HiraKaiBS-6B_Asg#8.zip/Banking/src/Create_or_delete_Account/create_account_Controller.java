package Create_or_delete_Account;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import sample.Notifications;

import javax.swing.*;
import java.io.IOException;
import java.sql.*;

import static sample.Main.getConnection_object;

public class create_account_Controller {

    public GridPane Grid;
    public TextField enter_pin;
    @FXML
    private TextArea enter_postalCode;

    @FXML
    private TextArea enter_city;

    @FXML
    public ChoiceBox<String> account_type;

    @FXML
    private TextArea enter_name;

    @FXML
    private TextArea enter_address;

    @FXML
    private TextArea enter_cnic;

    @FXML
    private Button button_create;
    @FXML
    private Button button_back;



    public void button_clicked(ActionEvent event) throws IOException, SQLException, InterruptedException {



        if (event.getSource() == button_create) {

            String[] fields = {enter_name.getText(), enter_cnic.getText(), enter_address.getText(), enter_postalCode.getText(), enter_city.getText(), enter_pin.getText()};

            if (fields == null) {
                System.out.println("field variable is empty ");
            } else {
                System.out.println("field variable is not null");
            }
            System.out.println("checking empty fields");

            for (String item : fields) {
                if (item.isEmpty()) {

                    System.out.println("Please fill all fields");
                    Notifications.show_Error_Notification("Please fill all fields", "Empty Fields");
                    return;
                }
            }
            if (!enter_cnic.getText().matches("[0-9]+") || enter_cnic.getText().length() != 13) {
                Notifications.show_Error_Notification("CNIC is invalid. Only write numbers from your CNIC", "Invalid CNIC");
                return;
            }
            if (account_type.getValue() == null) {
                Notifications.show_Error_Notification("Select your Account type", "No account type selected");
                return;
            }
            if (enter_pin.getText().length() != 5 || !enter_pin.getText().matches("[0-9]+")) {
                Notifications.show_Error_Notification("Enter valid Pin", "Invalid pin");
                return;

            }


            Connection con = getConnection_object();
            String insert_row_to_database = "INSERT INTO CUSTOMERS(name, cnic , address, postal_code, city, account_type,pin)VALUES(?,?,?,?,?,?,?)  ";


            PreparedStatement stmt = con.prepareStatement(insert_row_to_database);
            System.out.println("successfullly rreached here -----------------------------------");
            System.out.println("this is executing ");
            stmt.setString(1, enter_name.getText());  // ist paremeter is String i.e _name
            stmt.setString(2, enter_cnic.getText());
            stmt.setString(3, enter_address.getText());
            stmt.setString(4, enter_postalCode.getText());
            stmt.setString(5, enter_city.getText());
            stmt.setString(6, account_type.getValue());
            stmt.setString(7, enter_pin.getText());
            stmt.executeUpdate();

            con.commit();

            System.out.println("Inserted successfully");
            Notifications.show_Success_Notification("Account Created Successfully. Thankyou !!", "Thankyou");
            return;

        } else  //  If  back button is clicked
        {
            GridPane my_grid = FXMLLoader.load(getClass().getResource("/sample/main_page.fxml"));
            Grid.getChildren().setAll(my_grid);
        }

    }

}
