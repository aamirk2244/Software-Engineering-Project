
package Create_or_delete_Account;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import sample.Main;
import sample.Notifications;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import static sample.Main.getConnection_object;

public class delete_account {

    public AnchorPane my_anchor;
    @FXML
    private Button delete_button;

    @FXML
    private TextField enter_cnic;

    @FXML
    private TextField enter_pin;

    @FXML
    void button_clicked(ActionEvent event) throws SQLException, IOException {
        Connection con =  Main.getConnection_object();
        String query = "delete from CUSTOMERS WHERE cnic = ? and pin = ? ";
        PreparedStatement stmt = con.prepareStatement(query);
        try {
            stmt.setString(1, enter_cnic.getText());
            stmt.setString(2, enter_pin.getText());

            stmt.executeUpdate();
            con.commit();
            System.out.println("Inserted successfully");
            Notifications.show_Success_Notification("Account Deleted Successfully!!", "Account Deleted");
            Stage stage = (Stage) delete_button.getScene().getWindow();
            stage.close();
        } catch (SQLException throwables) {

            Notifications.show_Error_Notification("The account is not present", "Invalid Account");
            throwables.printStackTrace();

        }
        return;


    }

}
