package sample;

import javafx.scene.control.Alert;

public class Notifications {

    public static void show_Success_Notification(String msg, String title)
    {

        Alert errorAlert = new Alert(Alert.AlertType.INFORMATION);
        errorAlert.setHeaderText(title);
        errorAlert.setContentText(msg);
        errorAlert.showAndWait();
    }

    public static void show_Error_Notification(String msg, String title)
    {

        Alert errorAlert = new Alert(Alert.AlertType.ERROR);

        errorAlert.setHeaderText(title);
        errorAlert.setContentText(msg);
        errorAlert.showAndWait();
    }
}
