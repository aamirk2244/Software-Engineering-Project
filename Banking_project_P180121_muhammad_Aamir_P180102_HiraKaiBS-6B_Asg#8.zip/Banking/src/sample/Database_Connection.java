package sample;
import java.sql.*;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;

public class Database_Connection {
        public static Connection is_connection_made(String url) throws SQLException {
            //    String url = "jdbc:mysql://localhost:3306/BANK_PROJECT";    // url pattern for database created
            String name = "root";   // user name of the database
            String pass = "";
            Connection con = DriverManager.getConnection(url, name, pass);

            try{
                Class.forName("com.mysql.cj.jdbc.Driver");// to load the mysql driver
                con.setAutoCommit(false);
                con.commit();


            }catch (Exception e){
                System.out.println("Network error");
                JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(null), "Server is not running!",
                        "Network Error", JOptionPane.ERROR_MESSAGE);
                return null;

            }
            return con;
        }
  }
