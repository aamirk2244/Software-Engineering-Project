package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

public class Main extends Application  implements Runnable{

    public static Connection con;
    public static Connection getConnection_object(){return con;}   // returning made connection object
    public static void set_stage(String title, FXMLLoader fxmlLoader) throws IOException {
        Parent my_root = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle(title);
        stage.setScene(new Scene(my_root));
        stage.show();

    }

    public static void main(String[] args) throws SQLException {

        Main obj = new Main();
        Thread thread = new Thread(obj);
        thread.start();         // thread start for here
            con =  Database_Connection.is_connection_made("jdbc:mysql://localhost:3306/BANK_PROJECT");
            if(con == null)
            {
                System.out.println("database connection error");
                return;
            }else System.out.println("Connection to database established successfully");
        System.out.println("main is executed completely");
//        launch(args);
    }
    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("main_page.fxml"));
        primaryStage.setTitle("Banking System");
        primaryStage.setScene(new Scene(root, 700, 500));
        primaryStage.show();
    }


    @Override
    public void run() {
        // this is for thread execution
        System.out.println("Thread is called");
        launch();       // I run this in thread to make speed better

    }
}
