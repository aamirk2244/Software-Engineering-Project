public class rough_work extends Thread{
    public static void call_me(String var)
    {
        System.out.println("I am called by " + var);
    }
    public static void main(String[] args) {
        rough_work thread = new rough_work();
        thread.start();

        System.out.println("this is rough work");
        call_me("ist process");
    }
    public void run()
    {

        System.out.println("This code is in the thread ");
        call_me("Threaded process");
    }
}
