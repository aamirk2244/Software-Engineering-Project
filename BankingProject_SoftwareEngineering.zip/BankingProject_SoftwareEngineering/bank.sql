 
-- SQL Sample Database

use BANK_PROJECT;
DROP TABLE IF EXISTS CUSTOMERS;

DROP TABLE IF EXISTS ACCOUNTS;

USE BANK_PROJECT;

    create table CUSTOMERS (
        id integer not null auto_increment,
	name varchar(25),
       cnic char(13),
       address varchar(35),
       postal_code varchar(10),
       city varchar(25),
       account_type varchar(10),
       pin numeric(5),
       
       primary key (id)
    );


create table ACCOUNTS (
        id integer not null ,
	avail_balance int ,
	open_date date,
	pin numeric(5),
	
       primary key (id),
       foreign key (id) 
        references CUSTOMERS (id)
    );
  
  create view customer_account_view as select CUSTOMERS.id,name,cnic,address,postal_code,city,account_type,CUSTOMERS.pin,avail_balance,open_date from CUSTOMERS JOIN ACCOUNTS ON CUSTOMERS.id = ACCOUNTS.id ;

 
 DELIMITER $$
 create trigger after_insert_into_customer AFTER INSERT ON CUSTOMERS FOR EACH ROW BEGIN
    insert into ACCOUNTS(id,open_date,pin) select id,curdate(),pin from CUSTOMERS order by id desc limit 1;
     END $$

 DELIMITER ;
 
