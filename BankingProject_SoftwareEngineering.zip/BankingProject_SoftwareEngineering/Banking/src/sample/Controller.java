package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;

import java.io.IOException;

public class Controller{

    public Button deposit;
    public Button transfer;
    public Button delete;
    public GridPane Grid;
    public Pane pane;
    public Button account_history;
    @FXML
    private Button create;
    @FXML
    private Button withdraw;

    @FXML
    public void button_clicked(ActionEvent event) throws IOException {

        System.out.println("this is clicked");
        if (event.getSource() == create)
        {
            ////////////this code is for creating new scene //////////

//            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/CreateAccount/create_account.fxml"));

//            create_account.main(fxmlLoader);
            //////////////////////////////////

            GridPane my_grid = FXMLLoader.load(getClass().getResource("/Create_or_delete_Account/create_account.fxml"));
            System.out.println("printing children of create_account.fxml");
            Pane pane = (Pane) my_grid.getChildren().get(0);        // getting ist children which is a pane
//            System.out.println(pane.getChildren().get(13));
            System.out.println(pane.getChildren());
            ChoiceBox choice = (ChoiceBox) pane.getChildren().get(13);// on index 14 the choice box is present .. you can check it with  System.out.println(pane.getChildren())

            choice.getItems().add("Current");
            choice.getItems().add("Saving");

            Grid.getChildren().setAll(my_grid);


        }
        else if( event.getSource() == withdraw )
        {
            System.out.println("calling to withdraw");
//            Parent my_pane = FXMLLoader.load(getClass().getResource("/Withdraw/Withdraw.fxml"));
//
//            Grid.getChildren().setAll(my_pane);

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Withdraw/Withdraw.fxml"));
            Main.set_stage("Withdraw Amount",  fxmlLoader);


        }
        else if(event.getSource() == deposit )
        {
//            Parent my_pane = FXMLLoader.load(getClass().getResource("/Deposit/validate_cnic_pin.fxml"));
//
//            Grid.getChildren().setAll(my_pane);

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Deposit/validate_cnic_pin.fxml"));
            Main.set_stage("Deposit Amount",  fxmlLoader);



        }
        else if(event.getSource() == delete)
        {

//            Parent my_pane = FXMLLoader.load(getClass().getResource("/Create_or_delete_Account/delete_account.fxml"));
//
//            Grid.getChildren().setAll(my_pane);
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Create_or_delete_Account/delete_account.fxml"));
            Main.set_stage("Delete Account",  fxmlLoader);

        }
        else if(event.getSource() == account_history)
        {
//            Parent my_pane = FXMLLoader.load(getClass().getResource("/Create_or_delete_Account/delete_account.fxml"));
//
//            Grid.getChildren().setAll(my_pane);
            System.out.println("account history button is clicked");
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Account_History/choose_history_option.fxml"));
            Main.set_stage("History Option",  fxmlLoader);


        }
    }




}